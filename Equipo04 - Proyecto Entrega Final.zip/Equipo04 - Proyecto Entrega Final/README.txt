El proyecto se encuentra en la carpeta "cooperativa".


Los videos son uno con las actualizaciones 
y uno con las 4 funcionalidades tomando como ejemplo producto,
se encuentran en "DOCUMENTACION"
(el proyecto incluye las 4 funcionalidades como expusimos para usuario y pedidos solo que no los mostramos en el video).


Se encuentran validaciones en todos los formularios en los campos obligatorios,
así como la validación en base de datos y en código para que existan usernames únicos.


Al deployar el proyecto accediamos a este en la ruta del index:

http://localhost:8080/cooperativa/


Las clases de java se encuentran en cooperativa/src/main/java, 
mientras que los codigos de javascript, y los estilos estan en  cooperativa/src/main/webapp/resources 


Algunos usuarios con Rol de Administrador son:

username: DanielaL 
password: root

username: SaulIRV 
password: saul1234

username: DiegoIsla 
password: 1234diego


Algunos usuarios con Rol de Socio son:

username: Ana_lau 
password: a1n2a3

username: Juan_Rodriguez 
password: juanitobigotes

username: Rob1256 
password: robalram35

De igual forma este es el link al repositorio de github donde trabajamos en nuestros branchs, y lo que integrabamos en el master:
https://github.com/DanLK/PACooperativa

